# .env
DISCORD_TOKEN = <your-bot-token>
BOT_ID = <bot-id>
OWNER_ID = <your-id>